import React from "react";


import AreaManger from '../components/area_manager/index';


const routes = [
    { path: '/area-manager', component: <AreaManger /> }
];

export default routes;