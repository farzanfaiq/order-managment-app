const AreaManager = () => {
  return <h1>AreaManager</h1>;
};

export default AreaManager;